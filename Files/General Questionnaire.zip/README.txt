These PDFS are editable!

This means if you open them in your web browser such as Google Chrome, Mozilla Firefox, Microsoft Edge, Safari etc. you can directly type into the fields of the form. This means there's no need to print them as you can fill out the form directly on your computer!

Simply put, open the files as you normally would by double clicking them, then just click on the fields you'd like to edit. Once done, save the file then email it back as a reply to the original email.

Thank you for your cooperation.